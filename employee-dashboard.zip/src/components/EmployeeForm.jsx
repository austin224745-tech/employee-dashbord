import { useState } from "react";

const EmployeeForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    designation: "",
    location: "",
    salary: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Form submitted successfully! (No data posted)");
  };

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold mb-4 text-center">Employee Form</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input type="text" name="name" placeholder="Name" className="w-full border px-3 py-2 rounded" onChange={handleChange} required />
        <input type="text" name="designation" placeholder="Designation" className="w-full border px-3 py-2 rounded" onChange={handleChange} required />
        <input type="text" name="location" placeholder="Location" className="w-full border px-3 py-2 rounded" onChange={handleChange} required />
        <input type="number" name="salary" placeholder="Salary" className="w-full border px-3 py-2 rounded" onChange={handleChange} required />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Submit</button>
      </form>
    </div>
  );
};

export default EmployeeForm;
